#if defined(OPENSSL_NO_ASM)
# include "./crmf_no-asm.h"
#else
# include "./crmf_asm.h"
#endif
